Made by my bitch ass on 12/7/16
Contacts R US 

Commands

exit: 
exits application

about: 
developer information

info: 
gives # of contacts, # of companies, # of contacts per company

list:
lists all contacts formatted as name phone company email

remove: 
removes contact will tell if contact doesn't exist and will say contact is updated
Will ask how you want to look up contact ie name, phone, or company
Then what that part of the contact is ie Joe, 333-333-3333, Apple

note: lets user edit note. 
Will ask how you want to look up contact ie name, phone, or company
Then what that part of the contact is ie Joe, 333-333-3333, Apple
Asks for mode edit or see   edit allows you to change stuff see just shows it
if edit will ask you for a new note

add:
Allows user to add contact
will ask for
name
phone
email
company
note

load:
loads default commands

save:
asks for file name
saves current crap to a file

commands:
asks for a filename
will follow commands on file name





































